"""实验报告1：猜数字游戏。有效的1～100整数计入猜测次数。"""
import random


def main():
    N = random.randint(1, 100)
    count = 0
    print("欢迎参加猜数字游戏！范围：1～100。")
    while True:
        try:
            guess = int(input("请输入猜测的数字："))
        except ValueError:
            print("请输入整数！")
            continue
        if not 1 <= guess <= 100:
            print("请输入1～100之间的整数！")
            continue
        count += 1
        if guess > N:
            print("猜大了，请重新猜")
        elif guess < N:
            print("猜小了，请重新猜")
        else:
            print("恭喜你成功了")
            print(f"猜测次数：{count}次")
            break


if __name__ == "__main__":
    main()

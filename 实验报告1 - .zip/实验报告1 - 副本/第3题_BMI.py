"""实验报告1：输入身高、体重，按题目给定标准计算BMI。"""
import math


def read_positive(prompt):
    while True:
        try:
            value = float(input(prompt))
            if math.isfinite(value) and value > 0:
                return value
        except ValueError:
            pass
        print("请输入大于0的有效数字！")


def classify(bmi, normal_limit, obesity_limit):
    if bmi < 18.5:
        return "偏瘦"
    elif bmi < normal_limit:
        return "正常"
    elif bmi < obesity_limit:
        return "偏胖"
    else:
        return "肥胖"


def main():
    height = read_positive("请输入身高（米）：")
    weight = read_positive("请输入体重（千克）：")
    bmi = weight / height ** 2
    print(f"BMI值：{bmi:.2f}")
    print("国际BMI评价：" + classify(bmi, 25, 30))
    print("国内BMI评价：" + classify(bmi, 24, 28))
    print("国际指标：偏瘦<18.5；正常18.5≤BMI<25；")
    print("          偏胖25≤BMI<30；肥胖BMI≥30。")
    print("国内指标：偏瘦<18.5；正常18.5≤BMI<24；")
    print("          偏胖24≤BMI<28；肥胖BMI≥28。")


if __name__ == "__main__":
    main()
